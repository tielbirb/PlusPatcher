package com.plus.patcher

import com.android.apksig.ApkSigner
import com.github.junrar.Junrar
import java.io.*
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.zip.*

object Patcher {
    /** Extracts a zip or rar (detected by magic bytes, not file name). */
    fun extract(src: File, dest: File) {
        val magic = ByteArray(4); FileInputStream(src).use { it.read(magic) }
        if (magic[0] == 'R'.code.toByte() && magic[1] == 'a'.code.toByte()) {
            Junrar.extract(src, dest)
        } else if (magic[0] == 'P'.code.toByte() && magic[1] == 'K'.code.toByte()) {
            val root = dest.canonicalPath + File.separator
            ZipFile(src).use { z ->
                for (e in z.entries()) {
                    val f = File(dest, e.name)
                    if (!f.canonicalPath.startsWith(root)) continue
                    if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); z.getInputStream(e).use { i -> f.outputStream().use { o -> i.copyTo(o) } } }
                }
            }
        } else throw IOException("Mod file is not a valid .zip or .rar")
    }

    /** Godot mods can't work in a Unity APK, so reject them with a clear error. */
    fun rejectGodot(dir: File) {
        val ext = setOf("pck", "gd", "gdc", "tscn", "tres", "gdextension", "godot")
        val hit = dir.walkTopDown().filter { it.isFile }.firstOrNull {
            val n = it.name.lowercase()
            n.substringAfterLast('.', "") in ext || n == "project.godot" || n.contains("godot") && !n.endsWith(".png")
        }
        if (hit != null) throw IOException("This mod uses Godot (found ${hit.name}). PlusPatcher only supports Unity mods, so it can't be patched into the Unity APK.")
    }

    private fun target(rel: String, names: Set<String>): String? {
        val low = rel.lowercase()
        if (low.endsWith(".dll")) { // code mods (e.g. speed up Baldi) live in Assembly-CSharp.dll
            val t = "assets/bin/Data/Managed/" + rel.substringAfterLast('/')
            return if (t in names) t else null // only possible on Mono builds
        }
        if (low.endsWith(".exe") || low.endsWith(".pdb")) return null
        val i = low.indexOf("streamingassets/")
        if (i >= 0) return "assets/" + rel.substring(i + 16)
        if (Regex("(^|/)[^/]+_data/").containsMatchIn(low)) return null
        return "assets/$rel"
    }

    private class Counter(o: OutputStream) : FilterOutputStream(o) {
        var n = 0L
        override fun write(b: Int) { out.write(b); n++ }
        override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); n += len }
    }

    private fun alignExtra(offset: Long, nameLen: Int, align: Int): ByteArray {
        var p = ((align - (offset + 30 + nameLen) % align) % align).toInt()
        if (p in 1..3) p += align
        if (p == 0) return ByteArray(0)
        val b = ByteArray(p); b[0] = 0x35; b[1] = 0xD9.toByte(); b[2] = ((p - 4) and 0xFF).toByte(); b[3] = ((p - 4) shr 8).toByte()
        return b
    }

    fun patch(apk: File, modDir: File, unsigned: File, log: (String) -> Unit): Int {
        var root = modDir
        val kids = modDir.listFiles()?.filter { !it.name.startsWith("__MACOSX") } ?: emptyList()
        if (kids.size == 1 && kids[0].isDirectory) root = kids[0]
        val names = ZipFile(apk).use { z -> z.entries().asSequence().map { it.name }.toSet() }
        if (names.any { it.endsWith("libil2cpp.so") }) log("This APK is IL2CPP: script/code mods can't be patched, only assets.")
        val mods = LinkedHashMap<String, File>(); var skipped = 0
        root.walkTopDown().filter { it.isFile }.forEach {
            val rel = it.relativeTo(root).path.replace('\\', '/')
            val t = target(rel, names); if (t == null) skipped++ else mods[t] = it
        }
        val dlls = mods.keys.count { it.endsWith(".dll") }
        log("Injecting ${mods.size} files ($dlls code DLLs, $skipped skipped)…")
        val cnt = Counter(BufferedOutputStream(FileOutputStream(unsigned)))
        ZipFile(apk).use { zf ->
            ZipOutputStream(cnt).use { zo ->
                for (e in zf.entries()) {
                    val n = e.name
                    if (e.isDirectory || n in mods) continue
                    if (n.startsWith("META-INF/") && Regex(".*\\.(SF|RSA|DSA|EC|MF)$").matches(n)) continue
                    val ne = ZipEntry(n)
                    if (e.method == ZipEntry.STORED) {
                        ne.method = ZipEntry.STORED; ne.size = e.size; ne.compressedSize = e.size; ne.crc = e.crc
                        val ex = alignExtra(cnt.n, n.toByteArray().size, if (n.endsWith(".so")) 4096 else 4)
                        if (ex.isNotEmpty()) ne.extra = ex
                    }
                    zo.putNextEntry(ne); zf.getInputStream(e).use { it.copyTo(zo) }; zo.closeEntry()
                }
                for ((n, f) in mods) { zo.putNextEntry(ZipEntry(n)); f.inputStream().use { it.copyTo(zo) }; zo.closeEntry() }
            }
        }
        return mods.size
    }

    fun sign(ctx: android.content.Context, unsigned: File, out: File) {
        val ks = KeyStore.getInstance("PKCS12")
        ctx.assets.open("pp.p12").use { ks.load(it, "plusplus".toCharArray()) }
        val key = ks.getKey("pp", "plusplus".toCharArray()) as PrivateKey
        val cert = ks.getCertificate("pp") as X509Certificate
        val cfg = ApkSigner.SignerConfig.Builder("pp", key, listOf(cert)).build()
        ApkSigner.Builder(listOf(cfg)).setInputApk(unsigned).setOutputApk(out)
            .setV1SigningEnabled(true).setV2SigningEnabled(true).setV3SigningEnabled(true).setMinSdkVersion(26).build().sign()
    }
}
