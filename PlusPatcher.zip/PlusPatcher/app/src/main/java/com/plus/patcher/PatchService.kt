package com.plus.patcher

import android.app.*
import android.content.Intent
import android.net.Uri
import android.os.IBinder
import android.os.PowerManager
import java.io.File

object PatchState {
    var apkUri: Uri? = null; var modUri: Uri? = null
    @Volatile var msg = "Pick an APK and a mod, then tap Patch."; @Volatile var busy = false; @Volatile var ok = false
    @Volatile var listener: (() -> Unit)? = null
    fun post(m: String, done: Boolean = false, success: Boolean = false) {
        msg = m; if (done) { busy = false; ok = success }; listener?.invoke()
    }
}

class PatchService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("pp", "PlusPatcher", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "pp").setContentTitle("PlusPatcher")
            .setContentText("Patching in background…").setSmallIcon(android.R.drawable.stat_sys_download).setOngoing(true).build())
        val wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "pp:patch")
        wl.acquire(30 * 60 * 1000L)
        PatchState.busy = true
        Thread {
            try { run(); PatchState.post("Patched & signed! Tap Export to save the APK.", true, true) }
            catch (t: Throwable) { PatchState.post("Error: ${t.message ?: t.javaClass.simpleName}", true, false) }
            finally { if (wl.isHeld) wl.release(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        }.start()
        return START_NOT_STICKY
    }

    private fun copy(u: Uri, f: File) {
        (contentResolver.openInputStream(u) ?: throw Exception("Cannot open file")).use { i -> f.outputStream().use { o -> i.copyTo(o) } }
    }

    private fun run() {
        val w = File(cacheDir, "work"); w.deleteRecursively(); w.mkdirs()
        PatchState.post("Copying files…")
        val apk = File(w, "in.apk"); copy(PatchState.apkUri ?: throw Exception("No APK"), apk)
        val mod = File(w, "mod.bin"); copy(PatchState.modUri ?: throw Exception("No mod"), mod)
        PatchState.post("Extracting mod…")
        val dir = File(w, "mod"); dir.mkdirs(); Patcher.extract(mod, dir); mod.delete()
        Patcher.rejectGodot(dir)
        val un = File(w, "unsigned.apk")
        val added = Patcher.patch(apk, dir, un) { PatchState.post(it) }
        if (added == 0) throw Exception("No usable mod files found (only PC-only files?)")
        apk.delete(); dir.deleteRecursively()
        PatchState.post("Signing APK…")
        Patcher.sign(this, un, File(w, "out.apk")); un.delete()
    }
}
