package com.plus.patcher

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private class Pal(val bg: Int, val text: Int, val accent: Int)
    private val names = listOf("Breeze Magenta", "Green", "Dark Mode", "White", "Rainbow")
    private val pals = listOf(
        Pal(0xFFFFF0F8.toInt(), 0xFF3A1030.toInt(), 0xFFD81B8C.toInt()),
        Pal(0xFFEFFAF1.toInt(), 0xFF0F3A1B.toInt(), 0xFF2E9E4F.toInt()),
        Pal(0xFF121212.toInt(), 0xFFEEEEEE.toInt(), 0xFF8E5CF0.toInt()),
        Pal(0xFFFFFFFF.toInt(), 0xFF202020.toInt(), 0xFF455A64.toInt()),
        Pal(0xFFFAFAFA.toInt(), 0xFF202020.toInt(), 0xFFE53935.toInt()))
    private val prefs by lazy { getSharedPreferences("pp", Context.MODE_PRIVATE) }
    private var theme = 0
    private var anim: ValueAnimator? = null
    private val tinted = ArrayList<View>()
    private lateinit var status: TextView
    private lateinit var apkLbl: TextView
    private lateinit var modLbl: TextView
    private var apkName = "No APK selected"
    private var modName = "No mod selected"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        theme = prefs.getInt("theme", 0)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9)
        buildUi()
        PatchState.listener = { runOnUiThread { status.text = PatchState.msg } }
        if (isMiui()) AlertDialog.Builder(this).setTitle("Xiaomi / HyperOS detected")
            .setMessage("Please go to the settings and disable (MIUI Battery Saver) to make it patch in background.")
            .setPositiveButton("OK", null).show()
    }

    private fun isMiui(): Boolean {
        val m = Build.MANUFACTURER.lowercase()
        if (m.contains("xiaomi") || m.contains("redmi") || m.contains("poco")) return true
        return try {
            val g = Class.forName("android.os.SystemProperties").getMethod("get", String::class.java, String::class.java)
            (g.invoke(null, "ro.miui.ui.version.name", "") as String).isNotEmpty() || (g.invoke(null, "ro.mi.os.version.name", "") as String).isNotEmpty()
        } catch (e: Throwable) { false }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun accentBg(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(14).toFloat() }

    private fun button(t: String, p: Pal, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); textSize = 16f
        background = accentBg(p.accent); setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) }
        tinted.add(this)
    }

    private fun label(t: String, p: Pal, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(p.text); if (bold) setTypeface(null, Typeface.BOLD); setPadding(0, dp(6), 0, dp(2))
    }

    private fun buildUi() {
        anim?.cancel(); tinted.clear()
        val p = pals[theme]
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(48), dp(20), dp(24)) }
        val iv = ImageView(this).apply { setImageResource(R.drawable.ic_launcher); layoutParams = LinearLayout.LayoutParams(dp(72), dp(72)).apply { gravity = Gravity.CENTER_HORIZONTAL } }
        val title = label("PlusPatcher", p, 30f, true).apply { gravity = Gravity.CENTER; setTextColor(p.accent) }
        col.addView(iv); col.addView(title)
        col.addView(label("Baldi's Basics APK + PC mod patcher", p).apply { gravity = Gravity.CENTER })
        apkLbl = label(apkName, p); modLbl = label(modName, p)
        col.addView(button("1. Select Baldi APK", p) { pick(1, "application/vnd.android.package-archive") }); col.addView(apkLbl)
        col.addView(button("2. Select PC mod (.zip / .rar)", p) { pick(2, "*/*") }); col.addView(modLbl)
        col.addView(button("3. Patch (runs in background)", p) { startPatch() })
        status = label(PatchState.msg, p, 15f).apply { setPadding(0, dp(14), 0, dp(6)) }; col.addView(status)
        col.addView(button("4. Export patched APK", p) { export() })
        col.addView(button("UI colour: ${names[theme]}", p) { chooseTheme() })
        col.addView(label("Made by tielbirb (2026)\nNot affiliated with the Baldi's Basics Modding Team, Basically Games, or Unity.\nLicensed under the Apache License 2.0.", p, 12f).apply { gravity = Gravity.CENTER; alpha = .7f; setPadding(0, dp(24), 0, 0) })
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(col) })
        if (theme == 4) {
            anim = ValueAnimator.ofFloat(0f, 360f).apply {
                duration = 5000; repeatCount = ValueAnimator.INFINITE
                addUpdateListener {
                    val h = it.animatedValue as Float
                    title.setTextColor(Color.HSVToColor(floatArrayOf(h, .85f, .95f)))
                    tinted.forEachIndexed { i, v -> v.background = accentBg(Color.HSVToColor(floatArrayOf((h + i * 60) % 360, .8f, .9f))) }
                }
                start()
            }
        }
    }

    private fun chooseTheme() = AlertDialog.Builder(this).setTitle("UI colour")
        .setItems(names.toTypedArray()) { _, i -> theme = i; prefs.edit().putInt("theme", i).apply(); buildUi() }.show()

    private fun pick(code: Int, type: String) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(type), code)
    }

    private fun nameOf(u: Uri): String = contentResolver.query(u, null, null, null, null)?.use {
        if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null } ?: "file"

    private fun startPatch() {
        if (PatchState.busy) return toast("Already patching…")
        if (PatchState.apkUri == null || PatchState.modUri == null) return toast("Select both an APK and a mod first")
        PatchState.ok = false
        PatchState.post("Starting…")
        startForegroundService(Intent(this, PatchService::class.java))
    }

    private fun export() {
        if (!PatchState.ok || !File(cacheDir, "work/out.apk").exists()) return toast("Patch an APK first")
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType("application/vnd.android.package-archive").putExtra(Intent.EXTRA_TITLE, "PlusPatcher_patched.apk"), 3)
    }

    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        super.onActivityResult(req, res, d)
        val u = d?.data ?: return
        if (res != RESULT_OK) return
        when (req) {
            1 -> { PatchState.apkUri = u; apkName = nameOf(u); apkLbl.text = apkName }
            2 -> { PatchState.modUri = u; modName = nameOf(u); modLbl.text = modName }
            3 -> Thread {
                try {
                    contentResolver.openOutputStream(u, "wt")!!.use { o -> File(cacheDir, "work/out.apk").inputStream().use { it.copyTo(o) } }
                    runOnUiThread { toast("Exported!") }
                } catch (e: Exception) { runOnUiThread { toast("Export failed: ${e.message}") } }
            }.start()
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() { anim?.cancel(); PatchState.listener = null; super.onDestroy() }
}
